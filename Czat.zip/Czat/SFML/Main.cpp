#include <SFML/Network.hpp>
#include <iostream>



int main()
{

	std::cout << sf::IpAddress::getLocalAddress() << std::endl;
	std::cout << sf::IpAddress::getPublicAddress() << std::endl;
	std::cout << "serwer - 1, klient - 2" << std::endl;

	int choice;
	std::cin >> choice;
	getchar();
	sf::Packet pak;
	pak << "Witaj! Polaczyles sie z serverem";
	unsigned int port = 7676;

	switch (choice)
	{
	case 1:
	{
		sf::TcpListener listener;
		if (listener.listen(port) != sf::Socket::Done)
		{
			std::cout << "Nie mog� rozpocz�� nas�uchiwania na porcie " << port << std::endl;
		}
		std::cout << "Czekam na klienta" << std::endl;
		sf::TcpSocket client;

		listener.accept(client);
		std::cout << "Przyjeto i powitano klienta " << client.getRemoteAddress() << std::endl;
		if (client.send(pak) != sf::Socket::Done)
		{
			std::cout << "Nie mo�na wys�a� danych!\n";
			break;
		}
		while(1) {
			if (client.receive(pak) != sf::Socket::Done)
			{
				std::cout << "Nie mo�na odebra� danych!\n";
				break;
			}
			else
			{
				std::string odebrane;
				pak >> odebrane;
				std::cout << "Klient: " << odebrane << std::endl;
			}
			pak.clear();
			std::string odpowiedz;
			std::cout << "Ty: ";
			getline(std::cin, odpowiedz);
			pak << odpowiedz;
			if (client.send(pak) != sf::Socket::Done)
			{
				std::cout << "Nie mo�na wys�a� danych!\n";
				break;
			}
		} 

		break;
	}
	case 2:
	{
		std::string ip_str;
		sf::TcpSocket server;
		//sf::IpAddress ip = "192.168.8.100";
		std::cout << "Podaj IP: ";
		std::cin >> ip_str;
		sf::IpAddress ip = ip_str;

		if (server.connect(ip, port) != sf::Socket::Done)
		{
			std::cout << "Nie mo�na po��czy� si� z " << ip.toString() << std::endl;
			break;
		}
		while(1) {
			if (server.receive(pak) != sf::Socket::Done)
			{
				std::cout << "Nie mo�na odebra� danych!\n";
				break;
			}

			std::string odebrane;
			pak >> odebrane;
			std::cout << "SERVER: " << odebrane << std::endl;

			pak.clear();
			std::string odpowiedz;
			std::cout << "Ty: ";
			getline(std::cin, odpowiedz);
			pak << odpowiedz;
			if (server.send(pak) != sf::Socket::Done)
			{
				std::cout << "Nie mo�na wys�a� danych!\n";
				break;
			}
		}
		break;
	}
	}

	system("PAUSE");


	return 0;
}
